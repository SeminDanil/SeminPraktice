﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SeminPractice.Classes;
namespace SeminPractice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddStockrooms.xaml
    /// </summary>
    public partial class PageAddStockrooms : Page
    {
        private Stockrooms _currentStockrooms = new Stockrooms();
        public PageAddStockrooms(Stockrooms selectedManufacturer)
        {
            InitializeComponent();
            if (selectedManufacturer != null)
            {
                _currentStockrooms = selectedManufacturer;
                TitletxStockroom.Text = "Изменение склада";
                BtnAddStockroom.Content = "Изменить";
            }
            DataContext = _currentStockrooms;
        }

        private void BtnAddStockroom_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentStockrooms.Title)) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(_currentStockrooms.Address)) error.AppendLine("Укажите адрес");
            if (string.IsNullOrWhiteSpace(_currentStockrooms.Square)) error.AppendLine("Укажите площадь");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentStockrooms.IDSklad == 0)
            {
                SkladEntities.GetContext().Stockrooms.Add(_currentStockrooms);
                try
                {
                    SkladEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageStockrooms());
                    MessageBox.Show("Новый склад успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    SkladEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageStockrooms());
                    MessageBox.Show("Склад успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelStockroom_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageStockrooms());
        }
    }
}
