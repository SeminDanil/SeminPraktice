﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SeminPractice.Classes;

namespace SeminPractice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageStockrooms.xaml
    /// </summary>
    public partial class PageStockrooms : Page
    {
        public PageStockrooms()
        {
            InitializeComponent();
            DTGStockrooms.ItemsSource = SkladEntities.GetContext().Stockrooms.ToList();
        }

        private void MenuAddStockroom_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddStockrooms(null));
        }

        private void MenuEditStockroom_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddStockrooms((Stockrooms)DTGStockrooms.SelectedItem));
        }

        private void MenuDelStockroom_Click(object sender, RoutedEventArgs e)
        {
            var StockroomForRemoving = DTGStockrooms.SelectedItems.Cast<Stockrooms>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {StockroomForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SkladEntities.GetContext().Stockrooms.RemoveRange(StockroomForRemoving);
                    SkladEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DTGStockrooms.ItemsSource = SkladEntities.GetContext().Stockrooms.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
