﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SeminPractice.Classes;

namespace SeminPractice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddProducts.xaml
    /// </summary>
    public partial class PageAddProducts : Page
    {
        private Products _currentProducts = new Products();
        public PageAddProducts(Products selectedProduct)
        {
            InitializeComponent();
            if (selectedProduct != null)
            {
                _currentProducts = selectedProduct;
                TitletxProduct.Text = "Изменение товара";
                BtnAddProduct.Content = "Изменить";
            }
            DataContext = _currentProducts;
            CmbManufacturer.ItemsSource = SkladEntities.GetContext().Manufacturers.ToList();
            CmbManufacturer.SelectedValuePath = "IDManufacturer";
            CmbManufacturer.DisplayMemberPath = "Name";
            CmbStockroom.ItemsSource = SkladEntities.GetContext().Stockrooms.ToList();
            CmbStockroom.SelectedValuePath = "IDSklad";
            CmbStockroom.DisplayMemberPath = "Title";
        }

        private void BtnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentProducts.ProductName)) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.Price))) error.AppendLine("Укажите цену");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.Quantity))) error.AppendLine("Укажите количество");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.IDManufacturer))) error.AppendLine("Укажите изготовителя");
            if (string.IsNullOrWhiteSpace(_currentProducts.Address)) error.AppendLine("Укажите адрес производства");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.DateReceipts))) error.AppendLine("Укажите дату поставки");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.ProductCode))) error.AppendLine("Укажите код товара");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.IDSklad))) error.AppendLine("Укажите склад");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentProducts.IDTovar == 0)
            {
                SkladEntities.GetContext().Products.Add(_currentProducts);
                try
                {
                    SkladEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageProducts());
                    MessageBox.Show("Новый товар успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    SkladEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageProducts());
                    MessageBox.Show("Товар успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelProduct_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageProducts());
        }
    }
}
