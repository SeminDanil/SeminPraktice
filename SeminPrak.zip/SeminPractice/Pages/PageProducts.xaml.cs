﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SeminPractice.Classes;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace SeminPractice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageProducts.xaml
    /// </summary>
    public partial class PageProducts : Page
    {
        public PageProducts()
        {
            InitializeComponent();
            DTGProducts.ItemsSource = SkladEntities.GetContext().Products.ToList();
        }

        private void MenuAddProduct_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddProducts(null));
        }

        private void MenuEditProduct_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddProducts((Products)DTGProducts.SelectedItem));
        }

        private void MenuExportToExcelProduct_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Документ.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[38, 2] = "Дата:";
            ws.Cells[38, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = "Договор №2893";
            int indexRows = 6;
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "Название";
            ws.Cells[3][indexRows] = "Цена";
            ws.Cells[4][indexRows] = "Количество";
            ws.Cells[5][indexRows] = "Изготовитель";
            ws.Cells[6][indexRows] = "Адрес производства";
            ws.Cells[7][indexRows] = "Дата поставки";
            ws.Cells[8][indexRows] = "Код продукта";
            ws.Cells[9][indexRows] = "Склад";
            var printItems = DTGProducts.Items;
            foreach (Products item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.ProductName;
                ws.Cells[3][indexRows + 1] = item.Price;
                ws.Cells[4][indexRows + 1] = item.Quantity;
                ws.Cells[5][indexRows + 1] = item.Manufacturers.IDManufacturer;
                ws.Cells[6][indexRows + 1] = item.Address;
                ws.Cells[7][indexRows + 1] = item.DateReceipts;
                ws.Cells[8][indexRows + 1] = item.ProductCode;
                ws.Cells[9][indexRows + 1] = item.Stockrooms.Title;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 7] = "Подпись";
            ws.Cells[indexRows + 2, 8] = "Сёмин Д.Н.";
            excelApp.Visible = true;
        }

        private void MenuSortNameProduct1_Click(object sender, RoutedEventArgs e)
        {
            DTGProducts.ItemsSource = SkladEntities.GetContext().Products.OrderBy(x => x.ProductName).ToList();
        }

        private void MenuSortNameProduct2_Click(object sender, RoutedEventArgs e)
        {
            DTGProducts.ItemsSource = SkladEntities.GetContext().Products.OrderByDescending(x => x.ProductName).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DTGProducts.ItemsSource = SkladEntities.GetContext().Products.ToList();
        }

        private void MenuFilterProduct1_Click(object sender, RoutedEventArgs e)
        {
            DTGProducts.ItemsSource = SkladEntities.GetContext().Products.Where(x => x.Price <= 100).ToList();
        }

        private void MenuFilterProduct2_Click(object sender, RoutedEventArgs e)
        {
            DTGProducts.ItemsSource = SkladEntities.GetContext().Products.Where(x => x.Price >= 101 && x.Price <= 200).ToList();
        }

        private void MenuFilterProduct3_Click(object sender, RoutedEventArgs e)
        {
            DTGProducts.ItemsSource = SkladEntities.GetContext().Products.Where(x => x.Price >= 201).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DTGProducts.ItemsSource = SkladEntities.GetContext().Products.ToList();
        }

        private void MenuDelProduct_Click(object sender, RoutedEventArgs e)
        {
            var ProductForRemoving = DTGProducts.SelectedItems.Cast<Products>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {ProductForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SkladEntities.GetContext().Products.RemoveRange(ProductForRemoving);
                    SkladEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DTGProducts.ItemsSource = SkladEntities.GetContext().Products.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchStockroom_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DTGProducts.ItemsSource != null)
            {
                DTGProducts.ItemsSource = SkladEntities.GetContext().Products.Where(x => x.Stockrooms.Title.ToLower().Contains(SearchStockroom.Text.ToLower())).ToList();
            }
            if (SearchStockroom.Text.Count() == 0) DTGProducts.ItemsSource = SkladEntities.GetContext().Products.ToList();
        }
    }
}
