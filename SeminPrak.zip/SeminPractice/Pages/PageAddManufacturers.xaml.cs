﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SeminPractice.Classes;

namespace SeminPractice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddManufacturers.xaml
    /// </summary>
    public partial class PageAddManufacturers : Page
    {
        private Manufacturers _currentManufacturers = new Manufacturers();
        public PageAddManufacturers(Manufacturers selectedManufacturer)
        {
            InitializeComponent();
            if (selectedManufacturer != null)
            {
                _currentManufacturers = selectedManufacturer;
                TitletxManufacturer.Text = "Изменение изготовителя";
                BtnAddManufacturer.Content = "Изменить";
            }
            DataContext = _currentManufacturers;
        }

        private void BtnAddManufacturer_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentManufacturers.Name)) error.AppendLine("Укажите название");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentManufacturers.IDManufacturer == 0)
            {
                SkladEntities.GetContext().Manufacturers.Add(_currentManufacturers);
                try
                {
                    SkladEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageManufacturers());
                    MessageBox.Show("Новый изготовитель успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    SkladEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageManufacturers());
                    MessageBox.Show("Изготовитель успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelManufacturer_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageManufacturers());
        }
    }
}
