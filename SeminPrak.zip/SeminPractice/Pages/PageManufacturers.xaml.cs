﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SeminPractice.Classes;

namespace SeminPractice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageManufacturers.xaml
    /// </summary>
    public partial class PageManufacturers : Page
    {
        public PageManufacturers()
        {
            InitializeComponent();
            DTGManufacturers.ItemsSource = SkladEntities.GetContext().Manufacturers.ToList();
        }

        private void MenuAddManufacturer_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddManufacturers(null));
        }

        private void MenuEditManufacturer_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddManufacturers((Manufacturers)DTGManufacturers.SelectedItem));
        }

        private void MenuDelManufacturer_Click(object sender, RoutedEventArgs e)
        {
            var manufacturerForRemoving = DTGManufacturers.SelectedItems.Cast<Manufacturers>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {manufacturerForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SkladEntities.GetContext().Manufacturers.RemoveRange(manufacturerForRemoving);
                    SkladEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DTGManufacturers.ItemsSource = SkladEntities.GetContext().Manufacturers.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
